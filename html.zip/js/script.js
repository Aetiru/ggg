// Los datos de los paquetes
const packages = [
    {
        type: "Paquete",
        typeId: "A",
        description: "Enfocado Para Vehiculos De Carga Y Transporte De Elementos De Poco Peso.",
        ulr: `assets/svgs/start1.svg`
    },
    {
        type: "Paquete",
        typeId: "B",
        description: "Enfocado Para Vehiculos De Pasajeros Y Transporte Urbano.",
        ulr: `assets/svgs/start2.svg`
    },
    {
        type: "Paquete",
        typeId: "C",
        description: "Enfocado Para Vehiculos De Lujo Y Transporte Ejecutivo.",
        ulr: `assets/svgs/start3.svg`
    },
    {
        type: "Paquete",
        typeId: "D",
        description: "Enfocado Para Vehiculos Deportivos Y Alto Rendimiento.",
        ulr: `assets/svgs/start4.svg`
    }
];

// Función para manejar la apertura y cierre de paquetes
document.addEventListener("DOMContentLoaded", () => {
    const packagesGrid = document.querySelector('.packages__grid');
    const yearElement = document.querySelector('.footer-bottom div:first-child');
    const currentYear = new Date().getFullYear();
    yearElement.textContent = `${currentYear}, Tutti i diritti riservati`;
    if (!packagesGrid) {
        console.error("No se encontró el elemento .packages__grid en el DOM");
        return;
    }

    // Crear el overlay para el fondo oscuro
    const overlay = document.createElement('div');
    overlay.className = 'packages-overlay';
    overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); display: none; z-index: 799;';
    document.body.appendChild(overlay);

    // Generar el HTML para cada paquete
    packages.forEach((package, index) => {
        console.log('package: ', package)
        console.log('index: ', index)
        const packageElement = document.createElement('div');
        packageElement.className = `package package-${index}`;
        packageElement.dataset.index = index;
        packageElement.style.cursor = 'pointer'; // Add cursor pointer to all packages
        packageElement.innerHTML = `
            <img src="assets/svgs/card.svg" alt="">
            <img src="${package.ulr}" alt="" class="package-star">
            <div class="package__content">
                <h2 class="package__type">${package.type}</h2>
                <h1 class="package__type_id">${package.typeId}</h1>
                <div class="package__description">
                    <p>${package.description}</p>
                </div>
                <div class="package__corner">
                    <i class="fas fa-arrow-right package__arrow"></i>
                </div>
            </div>
            <button class="close-button" style="display: none; position: absolute; top: 10px; right: 10px; background: rgba(0,0,0,0.6); color: white; border: none; border-radius: 50%; width: 30px; height: 30px; cursor: pointer; z-index: 1500;">
                <i class="fas fa-times"></i>
            </button>
        `;
        console.log('packageElement: ', packageElement)
        packagesGrid.appendChild(packageElement);
    });

    let activePackage = null;

    // Función para expandir un paquete
    function expandPackage(packageElement) {

        console.log('packageElement: ', packageElement)
        // Si ya hay un paquete activo, no hacer nada
        if (activePackage) return;

        // Guardar referencia al paquete activo
        activePackage = packageElement;

        // Mostrar overlay
        overlay.style.display = 'block';

        // Mostrar botón de cerrar
        const closeButton = packageElement.querySelector('.close-button');
        if (closeButton) {
            closeButton.style.display = 'block';
        }

        // Aplicar estilos para expandir
        packageElement.style.position = 'fixed';
        packageElement.style.top = '50%';
        packageElement.style.left = '50%';
        packageElement.style.transform = 'translate(-50%, -50%) scale(1.5)';
        packageElement.style.zIndex = '1000';

        // Reducir opacidad de otros paquetes
        document.querySelectorAll('.package').forEach(pkg => {
            if (pkg !== packageElement) {
                pkg.style.opacity = '0.3';
            }
        });
    }

    // Función para cerrar un paquete expandido
    function closePackage() {
        if (!activePackage) return;

        // Get the card's index
        const index = parseInt(activePackage.dataset.index);
        const positions = ["12.5%", "37.5%", "62.5%", "87.5%"];


        // Ocultar botón de cerrar
        const closeButton = activePackage.querySelector('.close-button');
        if (closeButton) {
            closeButton.style.display = 'none';
        }

        // Ocultar overlay
        overlay.style.display = 'none';

        // Restaurar todos los paquetes a su opacidad normal
        document.querySelectorAll('.package').forEach(pkg => {
            pkg.style.opacity = '1';
        });

        // Restaurar el paquete activo a su estado normal
        activePackage.style.position = '';
        activePackage.style.top = '50%';
        activePackage.style.left = positions[index]; // Use the corresponding position
        activePackage.style.transform = '';
        activePackage.style.zIndex = '';

        // Limpiar la referencia al paquete activo
        activePackage = null;
    }


    // Event listener para abrir paquetes al hacer clic
    packagesGrid.addEventListener('click', (e) => {
        // Verificar si se hizo clic en el botón de cerrar
        if (e.target.closest('.close-button')) {
            e.stopPropagation();
            closePackage();
            return;
        }

        // Verificar si se hizo clic en un paquete
        const packageElement = e.target.closest('.package');

        console.log('packageElement: ', packageElement)

        if (packageElement) {
            expandPackage(packageElement);
        }
    });

    // Event listener para cerrar al hacer clic en el overlay
    overlay.addEventListener('click', closePackage);
});